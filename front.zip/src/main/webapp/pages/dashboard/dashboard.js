// Check if user is logged in
document.addEventListener('DOMContentLoaded', function() {
    // In a real app, you would check session/token
    const userName = localStorage.getItem('userName') || 'Student';
    document.getElementById('userName').textContent = userName;
    
    // Logout functionality
    document.getElementById('logoutBtn').addEventListener('click', function() {
        localStorage.removeItem('userName');
        window.location.href = '../auth/login.html';
    });
});