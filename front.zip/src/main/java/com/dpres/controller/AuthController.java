package com.dpres.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.dpres.model.User;
import com.dpres.service.UserService;

public class AuthController extends HttpServlet {
    private UserService userService;
    
    public void init() {
        userService = new UserService();
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        if ("register".equals(action)) {
            handleRegister(request, response);
        } else if ("login".equals(action)) {
            handleLogin(request, response);
        }
    }
    
    private void handleRegister(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        String institution = request.getParameter("institution");
        
        User user = new User(username, email, password, role, institution);
        boolean success = userService.registerUser(user);
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        if (success) {
            out.print("{\"success\": true, \"message\": \"Registration successful\"}");
        } else {
            out.print("{\"success\": false, \"message\": \"Registration failed\"}");
        }
    }
    
    private void handleLogin(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        User user = userService.authenticateUser(email, password);
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            session.setAttribute("userId", user.getId());
            session.setAttribute("userRole", user.getRole());
            
            out.print("{\"success\": true, \"message\": \"Login successful\", \"role\": \"" + user.getRole() + "\"}");
        } else {
            out.print("{\"success\": false, \"message\": \"Invalid credentials\"}");
        }
    }
}