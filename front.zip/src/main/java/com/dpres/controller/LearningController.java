package com.dpres.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.dpres.service.LearningService;
import org.json.JSONObject;

public class LearningController extends HttpServlet {
    private LearningService learningService;
    
    public void init() {
        learningService = new LearningService();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        if ("getCourses".equals(action)) {
            // Return list of courses
            String courses = learningService.getAllCourses();
            out.print(courses);
        } else if ("getCourse".equals(action)) {
            int courseId = Integer.parseInt(request.getParameter("courseId"));
            String course = learningService.getCourseById(courseId);
            out.print(course);
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        if ("submitQuiz".equals(action)) {
            int userId = Integer.parseInt(request.getParameter("userId"));
            int courseId = Integer.parseInt(request.getParameter("courseId"));
            int score = Integer.parseInt(request.getParameter("score"));
            
            boolean success = learningService.saveQuizResult(userId, courseId, score);
            
            JSONObject json = new JSONObject();
            json.put("success", success);
            json.put("score", score);
            out.print(json.toString());
        }
    }
}