package com.dpres.model;

public class Course {
    private int id;
    private String title;
    private String description;
    private String disasterType; // earthquake, fire, flood, etc.
    private String difficulty; // beginner, intermediate, advanced
    private int duration; // in minutes
    private String createdAt;
    
    // Constructors, Getters and Setters
    public Course() {}
    
    public Course(String title, String description, String disasterType, String difficulty, int duration) {
        this.title = title;
        this.description = description;
        this.disasterType = disasterType;
        this.difficulty = difficulty;
        this.duration = duration;
    }
    
    // Getters and setters...
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getDisasterType() { return disasterType; }
    public void setDisasterType(String disasterType) { this.disasterType = disasterType; }
    
    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }
    
    public int getDuration() { return duration; }
    public void setDuration(int duration) { this.duration = duration; }
    
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}