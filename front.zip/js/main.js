// Simple utility functions
const DisasterApp = {
    saveUser: function(userData) {
        localStorage.setItem('currentUser', JSON.stringify(userData));
    },

    getUser: function() {
        return JSON.parse(localStorage.getItem('currentUser')) || {};
    },

    logout: function() {
        localStorage.removeItem('currentUser');
        window.location.href = '../index.html';
    },

    showAlert: function(message) {
        alert(message);
    }
};

// Login functionality
if (window.location.pathname.includes('login.html')) {
    document.getElementById('loginForm')?.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        if (email && password) {
            // Simple demo login - in real app, call backend
            const userData = {
                name: email.split('@')[0],
                email: email,
                loginTime: new Date().toLocaleString()
            };
            DisasterApp.saveUser(userData);
            DisasterApp.showAlert('Login successful!');
            window.location.href = 'dashboard.html';
        } else {
            DisasterApp.showAlert('Please fill in all fields');
        }
    });
}

// Dashboard functionality
if (window.location.pathname.includes('dashboard.html')) {
    document.addEventListener('DOMContentLoaded', function() {
        const user = DisasterApp.getUser();
        if (!user.email) {
            window.location.href = 'login.html';
            return;
        }

        document.getElementById('userName').textContent = user.name || 'Student';
    });
}

// Register functionality
if (window.location.pathname.includes('register.html')) {
    document.getElementById('registerForm')?.addEventListener('submit', function(e) {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const institution = document.getElementById('institution').value;

        if (username && email && password) {
            const userData = {
                name: username,
                email: email,
                institution: institution,
                registeredAt: new Date().toLocaleString()
            };
            DisasterApp.saveUser(userData);
            DisasterApp.showAlert('Registration successful! You can now login.');
            window.location.href = 'login.html';
        } else {
            DisasterApp.showAlert('Please fill in all fields');
        }
    });
}

// Check authentication on protected pages
const protectedPages = ['dashboard.html', 'simulate.html', 'learn.html', 'plan.html', 'progress.html'];
const currentPage = window.location.pathname.split('/').pop();

if (protectedPages.includes(currentPage)) {
    document.addEventListener('DOMContentLoaded', function() {
        const user = DisasterApp.getUser();
        if (!user.email) {
            window.location.href = 'login.html';
        }
    });
}

// Simple progress tracking
DisasterApp.saveProgress = function(simulationType, score, total) {
    const progress = JSON.parse(localStorage.getItem('userProgress')) || [];
    progress.push({
        type: simulationType,
        score: score,
        total: total,
        date: new Date().toLocaleString()
    });
    localStorage.setItem('userProgress', JSON.stringify(progress));
};

DisasterApp.getProgress = function() {
    return JSON.parse(localStorage.getItem('userProgress')) || [];
};

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    console.log('Disaster Preparedness App Loaded');
});