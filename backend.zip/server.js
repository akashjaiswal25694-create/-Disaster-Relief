const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");
const quizRoutes = require("./routes/quizRoutes");

// Connect MongoDB
connectDB();

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Routes
app.use("/api/quiz", quizRoutes);

app.get("/", (req, res) => {
  res.send("🚀 Disaster Relief App Backend Running Successfully with Database");
});

// Start Server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`⬆ Server running on http://localhost:${PORT}`);
});
