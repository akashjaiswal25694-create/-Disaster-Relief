const express = require("express");
const Quiz = require("../models/Quiz");

const router = express.Router();

// Add a quiz question
router.post("/add", async (req, res) => {
  try {
    const newQuestion = new Quiz(req.body);
    await newQuestion.save();
    res.status(201).json({ message: "Quiz Question Added Successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all quiz questions
router.get("/", async (req, res) => {
  try {
    const questions = await Quiz.find();
    res.json(questions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
